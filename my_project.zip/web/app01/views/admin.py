from django.shortcuts import render, redirect
from app01 import models
from app01.utills.pagination import Pagination
from app01.utills.bootstrap import BootStrapModelForm
from django import forms
from django.core.exceptions import ValidationError
from app01.utills.encrypt import md5
# Create your views here.

class AdminEditModelform(BootStrapModelForm):
    class Meta:
        model = models.Admin
        fields=['username']

class AdminResetModelform(BootStrapModelForm):
    confirm_password = forms.CharField(
        label="確認密碼",
        widget=forms.PasswordInput
        )
    class Meta:
        model = models.Admin
        fields = ['password', 'confirm_password']
        widgets = {
            'password':forms.PasswordInput
        }

    def clean_password(self):
        pwd = self.cleaned_data.get("password")
        md5_pwd = md5(pwd)
        exists = models.Admin.objects.filter(id=self.instance.pk, password=md5_pwd).exists()
        if exists:
            raise ValidationError("密碼與之前不能一致")
        return md5(pwd)
    
    def clean_confirm_password(self):
        pwd = self.cleaned_data.get("password")
        confirm = md5(self.cleaned_data.get("confirm_password"))
        if pwd != confirm:
            raise ValidationError("密碼不一致")
        return confirm

class AdminModelform(BootStrapModelForm):
    confirm_password = forms.CharField(
        label="確認密碼",
        widget=forms.PasswordInput
        )

    class Meta:
        model = models.Admin
        fields = ["username", 'password','confirm_password']
        widgets = {
            'password':forms.PasswordInput
        }
    
    def clean_password(self):
        pwd = self.cleaned_data.get("password")
        return md5(pwd)
    
    def clean_confirm_password(self):
        pwd = self.cleaned_data.get("password")
        confirm = md5(self.cleaned_data.get("confirm_password"))
        if pwd != confirm:
            raise ValidationError("密碼不一致")
        return confirm




def admin_list(request):
    data_dict = {}
    value = request.GET.get('q') 
    if value:
        data_dict = {"username":value}

    queryset = models.Admin.objects.filter(**data_dict)
    page_object = Pagination(request,queryset)
    context = {
        'queryset' : page_object.page_queryset,
        'page_string' : page_object.html(),
    }
    return render(request, "admin_list.html", context)



def admin_add(request):
    if request.method == "GET":
        form = AdminModelform()
        return render(request, "admin_add.html", {"form":form})
    
    form = AdminModelform(data=request.POST)
    if form.is_valid():
        form.save()
        return redirect("/admin/list")
    return render(request, "admin_add.html", {"form":form})


def admin_edit(request, nid):
    row_object = models.Admin.objects.filter(id=nid).first()
    title = "編輯管理員"

    if not row_object :
        return render(request, 'error.html')

    if request.method == 'GET':
        form = AdminEditModelform(instance=row_object)
        return render(request, "admin_edit.html", {'form':form})
    form = AdminEditModelform(data=request.POST, instance=row_object)
    if form.is_valid():
        form.save() 
        return redirect("/admin/list")
    return render(request, "change.html", {"form":form, "title":title})


def admin_reset(request, nid):
    row_object = models.Admin.objects.filter(id=nid).first()
    title = "重置密碼 - {}".format(row_object.username)

    if not row_object :
        return render(request, 'error.html')


    if request.method == "GET":
        form = AdminResetModelform()
        return render(request, "change.html", {'form':form, "title":title})
    form = AdminResetModelform(data=request.POST, instance=row_object)
    if form.is_valid():
        form.save()
        return redirect("/admin/list")
    return render(request, "change.html", {"form":form, "title":title})


def admin_delete(request, nid):
    models.Admin.objects.filter(id=nid).delete()
    return redirect('/admin/list/')
         

