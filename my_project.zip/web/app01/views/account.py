from django.shortcuts import render,redirect,HttpResponse
from django import forms
from app01 import models
from app01.utills.encrypt import md5
from app01.utills.bootstrap import BootStrapForm
from app01.utills.code import check_code
from io import BytesIO

class LoginForm(BootStrapForm):
    username = forms.CharField(
        label = "用戶名",
        widget=forms.TextInput,
        required=True
    )
    password = forms.CharField(
        label="密碼",
        widget=forms.PasswordInput,
        required=True
    )
    code = forms.CharField(
        label="驗證碼",
        widget=forms.TextInput,
        required=True
    )

    def clean_password(self):
        pwd = self.cleaned_data.get("password")
        return md5(pwd)


def login(request):
    if request.method == "GET":
        form = LoginForm()
        return render(request, "login.html", {"form":form})
    
    form = LoginForm(data=request.POST)

    if form.is_valid():

        user_input_code = form.cleaned_data.pop('code')
        code = request.session.get('image_code', "")
        if code.upper() != user_input_code.upper():
            form.add_error("code", "驗證碼錯誤")
            return render(request, 'login.html', {'form': form})

        admin_object = models.Admin.objects.filter(**form.cleaned_data).first()
        if not admin_object:
            form.add_error("password","用戶名或密碼錯誤")
            return render(request, "login.html", {"form":form})
        request.session["info"] = {'id':admin_object.id,'name':admin_object.username}
        request.session.set_expiry(60 * 60 * 24 * 7)
        return redirect("/admin/list/")
    return render(request, "login.html", {"form":form})



def image_code(request):
    img, code_string = check_code()
    request.session['image_code'] = code_string
    request.session.set_expiry(60)

    stream = BytesIO()
    img.save(stream, 'png')
    return HttpResponse(stream.getvalue())


def logout(request):
    request.session.clear()
    return redirect('/login')