from django.shortcuts import render, redirect
from app01 import models
from app01.utills.pagination import Pagination
from app01.utills.bootstrap import BootStrapModelForm
from app01.utills.form import UserModelform,PrettyForm
# Create your views here.

def pretty_list(request):
    data_dict = {}
    value = request.GET.get('q') 
    if value:
        data_dict = {"mobile__contains":value}

    queryset = models.PrettyNum.objects.filter(**data_dict)
    page_object = Pagination(request,queryset)
    context = {
        'page_string' : page_object.html(),
        'queryset' : page_object.page_queryset,
    }
    return render(request, "pretty_list.html", context)





def pretty_add(request):
    if request.method == "GET":
        form = PrettyForm()
        return render(request, "pretty_add.html", {"form": form})   
    
    data = PrettyForm(data=request.POST)
    if data.is_valid():
        data.save()
        return redirect("/pretty/list")
    return render(request, "pretty_add.html", {"form": data})


def pretty_edit(request, nid):
    row_object = models.PrettyNum.objects.filter(id=nid).first()
    if request.method == "GET":
        form = PrettyForm(instance=row_object)
        return render(request, "pretty_edit.html", {"form":form})
    
    data = PrettyForm(request.POST, instance=row_object)
    if data.is_valid():
        data.save()
        return redirect("/pretty/list")
    return render(request, "pretty_edit.html", {"form":data})


def pretty_delete(request, nid):
    models.PrettyNum.objects.filter(id=nid).delete()
    return redirect("/pretty/list/")


    