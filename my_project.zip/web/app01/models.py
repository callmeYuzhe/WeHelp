from django.db import models

# Create your models here.
class Admin(models.Model):
    username = models.CharField(verbose_name="用戶名", max_length=32)
    password = models.CharField(verbose_name="密碼", max_length=64)


class Department(models.Model):
    # 部門表
    title = models.CharField(verbose_name="標題", max_length=16)
    def __str__(self):
        return self.title


class UserInfo(models.Model):
    # 員工表
    name = models.CharField(verbose_name="姓名", max_length=16)
    password = models.CharField(verbose_name="密碼", max_length=32)
    age = models.IntegerField(verbose_name="年齡")
    account = models.DecimalField(verbose_name="帳戶餘額", max_digits=10, decimal_places=2, default=0)
    create_time = models.DateField(verbose_name="入職時間")
    depart = models.ForeignKey(to="Department", to_field="id", on_delete=models.CASCADE)
    
    gender_choices = (
        (1,"男"),(2,"女")
        )
    gender = models.SmallIntegerField(verbose_name="性別", choices=gender_choices)


class PrettyNum(models.Model):
    mobile = models.CharField(max_length=11, verbose_name="手機號碼")
    price = models.IntegerField(default=0, verbose_name="價格")
    level_choice = (
        (1, "黑鐵"),
        (2, "青銅"),
        (3, "白銀"),
        (4, "黃金"),
    )
    level = models.SmallIntegerField(choices=level_choice, verbose_name="等級", default=1)
    status_choice = (
        (1, "已占用"),
        (2, "未使用"),
    )
    status = models.SmallIntegerField(choices=status_choice, verbose_name="狀態")


