from app01 import models
from django import forms
from django.core.validators import RegexValidator
from app01.utills.bootstrap import BootStrapModelForm
from django.core.exceptions import ValidationError



class UserModelform(BootStrapModelForm):
    class Meta:
        model = models.UserInfo
        fields = ["name","password","age","account","create_time","depart","gender"]
    name = forms.CharField(min_length=3, label="用户名")
        # widgets = {
        #     "name" : forms.TextInput(attrs={"class":"form-control"})
        # }


class PrettyForm(BootStrapModelForm):
    class Meta:
        model = models.PrettyNum
        fields = ["mobile", "price", "level", "status"]
    mobile = forms.CharField(
        label="手機號碼",
        validators = [RegexValidator(r'^09\d{8}$', '手機號必須十位且09開頭')],
    )


